qwerty-XX readme.txt ver.5.02
作者：qwerty
twitter: https://twitter.com/hoyoqwerty
ダウンロードページ: https://hoyoqwerty.github.io/

qwerty-XX のreadmeへようこそ！


・qwerty-XXはWindowsをより使いやすくしたいために個人的に制作したものです。
　しかしyoutubeやtwitterを始めだしたことでqwerty-XXも世に出せるのではと思い公開をいたしました。

・qwerty-XXはWindowsXP、Vista、7、8、10、11で動作するランチャーアプリです。
　(あくまで推奨はWindows10、11です)
　合計300個の項目をアプリ内で登録できます。

・その他の使い方はオブジェクトにマウスカーソルをかざすと表示される「ツールチップ」にて、
確認することができます。

・更新内容に関しては、同フォルダ内の「Release Note.txt」を参照してください。

・「qwerty-XX」フォルダ内は以下のような構成になっています。
：概要
--------------------------------------------------------------------------------
qwerty-XX.exe
：qwerty-XX本体のアプリケーション
appicon.png
：qwerty-XXのアイコンの画像ファイル
hspext.dll
hspinet.dll
：HSP3の拡張ライブラリファイル
keyHook.dll
：キーフック用拡張ライブラリファイル
kiyaku.txt
：qwerty-XXの利用規約のテキストファイル
LICENSE.txt
NOTICE.txt
：WebView2Loader.dllのライセンス規約、3箇条BSDについてのテキストファイル
readme.txt
：このテキストファイル
Release Note.txt
：qwerty-XXの更新履歴のテキストファイル
time
：Windows クロック起動用のショートカットファイル
WebView2Loader.dll
：qwerty-XX インターネットブラウザー用のライブラリファイル

・「qwerty-XX\animation」フォルダ内は以下のような構成になっています。
--------------------------------------------------------------------------------
95test.jpg
2000test.jpg
dostest.jpg
nonetest.jpg
vistatest.jpg
：qwerty-XX 設定でのプレビュー用の画像ファイル
pc-98startupbeep.wav
pc-98startupseek.wav
：MS-DOS(PC-98)風起動アニメーション用の音声ファイル
qwerty-xxlikewindows95.jpg
qwerty-xxlikewindows952.jpg
qwerty-xxlikewindows2000.jpg
qwerty-xxlikewindowsvista.mp4
：qwerty-XX起動アニメーション用画像、動画ファイル
qwerty-xxlikewindows953
qwerty-xxlikewindows20002.jpg
：qwerty-XX終了アニメーション用画像ファイル

・「qwerty-XX\cnvutf8toansi」フォルダ内は以下のような構成になっています。
--------------------------------------------------------------------------------
cnvutf8toansi.exe
：UTF-8形式とANSI形式のテキストファイルを双方向で変換するためのアプリケーション

・「qwerty-XX\default」フォルダ内は以下のような構成になっています。
--------------------------------------------------------------------------------
defaultimage.png
：qwerty-XXのデフォルトの背景画像ファイル

・「qwerty-XX\mp3infp」フォルダ内は以下のような構成になっています。
--------------------------------------------------------------------------------
mp3infpcheck.exe
：音声ファイルから情報を取得するためのアプリケーション
mp3infp.dll
：音声ファイル情報取得用拡張ライブラリファイル

・「qwerty-XX\windowsbat」フォルダ内は以下のような構成になっています。
--------------------------------------------------------------------------------
windowsbatx64.exe
：batファイルを実行するためのアプリケーション(64bit環境用)
windowsbatx86.exe
：batファイルを実行するためのアプリケーション(32bit環境用)

※ここに書かれていないファイル、もしくは本来の場所と違う場所にあるファイルについては、
qwerty-XX ver.5.00以降に必要ではないファイルで、
多くの場合、一時ファイルは過去のqwerty-XXで必要だったファイルです。
ver.5.00以降のqwerty-XXを継続して使用する場合、削除しても問題はありません。

※「pc-98startupbeep.mp3」と「pc-98startupseek.mp3」の二つの音声は、
NaopyHobbyLand様のyoutube動画「PC-9801シリーズ用 歴代Windows起動画面集め」
(https://youtu.be/lhHvjWNb8AA?si=YlwGSnVxC-w61faU)
から録られています。NaopyHobbyLand様、ご協力に深く感謝いたします。