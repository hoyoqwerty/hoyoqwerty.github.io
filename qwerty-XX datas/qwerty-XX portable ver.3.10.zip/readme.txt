qwerty-XX readme.txt ver.3.10
作者：qwerty
twitter:https://twitter.com/hoyoqwerty
ダウンロードページ:https://hoyoqwerty.github.io/

qwerty-XX のreadmeへようこそ！


・qwerty-XXはWindowsをより使いやすくしたいために個人的に制作したものです。
　しかしyoutubeやtwitterを始めだしたことでqwerty-XXも世に出せるのではと思い公開をいたしました。

・qwerty-XXはWindowsXP、Vista、7、8、10、11で動作するランチャーアプリです。
　(あくまで推奨はWindows10、11です)
　合計200個の項目をアプリ内で登録できます。

・更新内容に関しては、同フォルダ内の「Release Note.txt」を参照してください。

・「qwerty-XX」フォルダ内は以下のような構成になっています。

ファイル名						概要
-------------------------------------------------------
qwerty-XX.exe					qwerty-XX本体
Release Note.txt				qwerty-XXの更新履歴
windowsbatx64.exe			qwerty-XX連携のbatファイル生成用アプリケーション64bit用
windowsbatx86.exe			qwerty-XX連携のbatファイル生成用アプリケーション32bit用
cnvutf8toansi.exe				qwerty-XX連携のANSI文字列への変換用アプリケーション
mp3infpcheck.exe				qwerty-XX連携のmp3情報取得用アプリケーション
appicon.png					qwerty-XXのアプリケーションアイコン
hspext.dll						hsp3標準のライブラリファイル(命令拡張など)
hspinet.dll					hsp3標準のライブラリファイル(インターネット通信など)
kiyaku.txt						利用規約
time.lnk						Windows標準アプリケーション「クロック」起動用ショートカット
readme.txt					このテキストファイル
pc-98startupbeep.mp3※		MS-DOS(PC-98)風起動音(ビープ音)
pc-98startupseek.mp3※		MS-DOS(PC-98)風FDDシーク音
qwerty-xxlikewindows2000.jpg 	Windows2000風起動アニメーション用画像
qwerty-xxlikewindows20002.jpg	Windows2000風終了アニメーション用画像
qwerty-xxlikewindows95.jpg		Windows95風起動アニメーション用画像
qwerty-xxlikewindows952.jpg	Windows95風終了アニメーション用画像
qwerty-xxlikewindows953.jpg	Windows95風終了アニメーション用画像
mp3infp.dll					「メディアプレーヤー」用ライブラリファイル
keyHook.dll					「メディアプレーヤー」用ライブラリファイル

※「pc-98startupbeep.mp3」と「pc-98startupseek.mp3」の二つの音声は、
NaopyHobbyLand様のyoutube動画「PC-9801シリーズ用 歴代Windows起動画面集め」
(https://youtu.be/lhHvjWNb8AA?si=YlwGSnVxC-w61faU)
から録られています。NaopyHobbyLand様、ご協力に深く感謝いたします。

(ここから下はコピー用の一時ファイルです)
ファイル名						概要
-------------------------------------------------------
compressdatas.zip				「qwerty-XX」フォルダ内容が内包されたzipファイル
ZLibWrap.dll					hsp3のライブラリファイル
qwerty-XX extractor.exe			「compressdatas.zip」解凍用アプリケーション