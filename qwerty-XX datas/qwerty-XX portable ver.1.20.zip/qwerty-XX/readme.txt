qwerty-XX readme.txt ver.1.20
作者：qwerty　twitter:https://twitter.com/hoyoqwerty

qwerty-XX のreadmeへようこそ！


・qwerty-XXはWindowsをより使いやすくしたいために元々個人的に制作したものです。
　しかしyoutubeやtwitterを始めだしたことでqwerty-XXも世に出せるのではと思い公開をいたしました。

・qwerty-XXはWindows10、Windows11で動作するランチャーアプリです。
　合計200個の項目をアプリ内で登録できます。

・更新内容に関しては、同フォルダ内の「Release Note.txt」を参照してください。

・「qwerty-XX」フォルダ内は以下のような構成になっています。

ファイル名		概要
-------------------------------------------------
qwerty-XX.exe		qwerty-XX本体
Release Note.txt	qwerty-XXの更新履歴
windowsbatx64.exe	qwerty-XX連携のbatファイル生成用アプリ64bitWindowsver
windowsbatx86.exe	qwerty-XX連携のbatファイル生成用アプリ32bitWindowsver
appicon.ico		qwerty-XXのアプリアイコン
hspext.dll		hsp3のライブラリファイル
kiyaku.txt		利用規約
time.lnk		Windows標準アプリケーション「クロック」起動用ショートカット
readme.txt		このテキストファイル

(ここから下はコピー用の一時ファイルです)
compressdatas.zip	「qwerty-XX」フォルダ内容が内包されたzipファイル
ZLibWrap.dll		hsp3のライブラリファイル
qwerty-XX extractor.exe	「compressdatas.zip」解凍用ファイル